﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Airlines.Classes;

namespace Airlines.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddAirplane.xaml
    /// </summary>
    public partial class PageAddAirplane : Page
    {
        private Airplane _currentAirplane = new Airplane();
        public PageAddAirplane(Airplane selectedAirplane)
        {
            InitializeComponent();
            if (selectedAirplane != null)
            {
                _currentAirplane = selectedAirplane;
                TitletxAirplane.Text = "Изменение самолёта";
                BtnAddAirplane.Content = "Изменить";
            }
            DataContext = _currentAirplane;       
        }

        private void BtnAddAirplane_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentAirplane.Model)) error.AppendLine("Укажите модель");         
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentAirplane.LifeTime))) error.AppendLine("Укажите готовность");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentAirplane.DateOfManufacture))) error.AppendLine("Укажите дату создания");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentAirplane.IdAirplane == 0)
            {
                Airlines27Entities.GetContext().Airplane.Add(_currentAirplane);
                try
                {
                    Airlines27Entities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageAirplane());
                    MessageBox.Show("Новый самолёт успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    Airlines27Entities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageAirplane());
                    MessageBox.Show("самолёт успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
        private void BtnCanceAirplane_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAirplane());
        }
    }
}

