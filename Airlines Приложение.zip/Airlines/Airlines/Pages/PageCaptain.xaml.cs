﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Airlines.Classes;


namespace Airlines.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageCapitan.xaml
    /// </summary>
    public partial class PageCaptain : Page
    {
        public PageCaptain()
        {
            InitializeComponent();
            DtgCaptains.ItemsSource = Airlines27Entities.GetContext().Captain.ToList();
        }

        private void SearchCapitan_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void MenuAddCapitan_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddCaptain(null));
        }

        private void MenuEditCapitan_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddCaptain((Captain)DtgCaptains.SelectedItem));
        }

        private void MenuExportToExcelCapitan_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuExportToWordCapitan_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortDescCapitan1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortDescCapitan2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortClear_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterCapitan1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterCapitan2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterCapitan3_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuDelProduct_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuDelCapitan_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
