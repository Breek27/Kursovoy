﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Airlines.Classes;

namespace Airlines.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageReys.xaml
    /// </summary>
    public partial class PageReys : Page
    {
        public PageReys()
        {
            InitializeComponent();
            DtgReys.ItemsSource = Airlines27Entities.GetContext().Reys.ToList();
        }

        private void MenuAddReys_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuEditReys_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuExportToExcelReys_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuExportToWordReys_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortDescReys1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortDescReys2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortClear_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterReys1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterReys2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterReys3_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuDelProduct_Click(object sender, RoutedEventArgs e)
        {

        }

        private void SearchReys_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
