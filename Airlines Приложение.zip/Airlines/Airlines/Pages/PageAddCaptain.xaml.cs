﻿using Airlines.Classes;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Airlines.Pages;

namespace Airlines.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddCaptain.xaml
    /// </summary>
    public partial class PageAddCaptain : Page
    {
        private Captain _currentCaptain = new Captain();
        public PageAddCaptain(Captain selectedCaptain)
        {
            InitializeComponent();
            if (selectedCaptain != null)
            {
                _currentCaptain = selectedCaptain;
                TitletxCaptain.Text = "Изменение капитана";
                BtnAddCaptain.Content = "Изменить";
            }
            DataContext = _currentCaptain;
        }

        private void BtnAddCaptain_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentCaptain.Fio)) error.AppendLine("Укажите ФИО");
            if (string.IsNullOrWhiteSpace(_currentCaptain.Adress)) error.AppendLine("Укажите адрес");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentCaptain.Phone))) error.AppendLine("Укажите телефон");
            if (string.IsNullOrWhiteSpace(_currentCaptain.Fio)) error.AppendLine("Укажите ФИО");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentCaptain.IdCaptain == 0)
            {
                Airlines27Entities.GetContext().Captain.Add(_currentCaptain);
                try
                {
                    Airlines27Entities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageCaptain());
                    MessageBox.Show("Новый капитан успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    Airlines27Entities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageCaptain());
                    MessageBox.Show("Капитан успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }



        private void BtnCancelCaptain_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageCaptain());
        }
    }
}

