﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Airlines.Classes;

namespace Airlines.Pages
{
    /// <summary>
    /// Логика взаимодействия для PagePassangers.xaml
    /// </summary>
    public partial class PagePassangers : Page
    {
        public PagePassangers()
        {
            InitializeComponent();
            DtgPassangers.ItemsSource = Airlines27Entities.GetContext().Passangers.ToList();
        }

        private void SearchPassangers_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void MenuAddPassangers_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuEditPassangers_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuExportToExcelPassangers_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuExportToWordPassangers_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortDescPassangers1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortDescPassangers2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortClear_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterPassangers1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterPassangers2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterPassangers3_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterPassangers3_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuDelPassangers_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
