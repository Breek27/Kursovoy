﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Airlines.Classes;


namespace Airlines.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageMarshrut.xaml
    /// </summary>
    public partial class PageMarshrut : Page
    {
        public PageMarshrut()
        {
            InitializeComponent();
            DtgMarshrut.ItemsSource = airlinesEntities.GetContext().Marshrut.ToList();
        }

        private void MenuAddMarshrut_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuEditMarshrut_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuExportToExcelMarshrut_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuExportToWordMarshrut_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortDescMarshrut1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortDescMarshrut2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortClear_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterMarshrut1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterMarshrut2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterMarshrut3_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuDelMarshrut_Click(object sender, RoutedEventArgs e)
        {

        }

        private void SearchMashrut_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
