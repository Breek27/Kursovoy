﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Airlines.Classes;

namespace Airlines.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAirlpane.xaml
    /// </summary>
    public partial class PageAirlpane : Page
    {
        public PageAirlpane()
        {         
            InitializeComponent();
            DtgAirplane.ItemsSource = airlinesEntities.GetContext().Airplane.ToList();
        }

        private void SearchAirlpane_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void MenuAddAirlpane_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuEditAirlpane_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuExportToExcelAirlpane_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuExportToWordAirlpane_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortDescAirlpane1_Click(object sender, RoutedEventArgs e)
        {

        }

      
        private void MenuSortClear_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterAirlpane1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuDelAirplane_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuAirlpane2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuFilterAirlpane3_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortDescProduct2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortDescAirplane2_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
