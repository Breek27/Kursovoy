﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Airlines.Classes;
using Airlines.Pages;




namespace Airlines
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ClassFrame.frmObj = frameAirlines;
            
        }

        private void BTNAirplane_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAirlpane());
            Image1.Visibility = Visibility.Hidden;
        }

        private void BTNCapitan_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageCapitan());
            Image1.Visibility = Visibility.Hidden;
        }

        private void BTNPassangers_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PagePassangers());
            Image1.Visibility = Visibility.Hidden;
        }

        private void BTNMarshrut_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageMarshrut());
            Image1.Visibility = Visibility.Hidden;
        }

        private void BTNReys_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageReys());
            Image1.Visibility = Visibility.Hidden;
        }
    }
}
